/* This file was generated using stamper.c to create the next version release.          */
/* If you need to update this to the next release version, see fontforge/GNUmakefile.in */

#define LibFF_ModTime		FONTFORGE_MODTIME_RAW	/* Seconds since 1970 (standard unix time) */
#define LibFF_ModTime_Str	FONTFORGE_MODTIME_STR
#define LibFF_VersionDate	FONTFORGE_VERSIONDATE_RAW	/* Year, month, day */
